clear
pip install colorama
pip install requests
clear
sleep 2
echo ""
echo -e "\e[91mFinished installation!\e[0m"
echo -e "\e[91mNow you can run the command: python iphunter.py \e[0m"