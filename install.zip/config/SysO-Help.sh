#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# SysO-Help
#
# VARIABLES
#
PWD=$(pwd)
green='\033 [32m']
white='\033 [37m']
red='\033 [31m']
#
# CODE
#
clear
echo -e "${green}
┌═══════════┐
█ ${white}SysO-Help ${green}█
└═══════════┘
┃ ┌═════════════════════════════════════════┐
└═>>█ ${white}Print SysO-Termux Help Menu ${green}█
     └═════════════════════════════════════════┘

┌═════════════┐
█ ${white}SysO-Update ${green}█
└═════════════┘
┃ ┌═══════════════════════════════════┐
└═>>█ ${white}Reinstall and Update SysO-Termux ${green}█
     └═══════════════════════════════════┘

┌══════════┐
█ ${white}SysO-Bot ${green}█
└══════════┘
┃ ┌══════════════════════════════════════════┐
└═>>█ ${white}Redirect to BOT Informatic in Termux ${green}█
     └══════════════════════════════════════════┘

┌═══════════┐
█ ${white}SysO-Lock ${green}█
└═══════════┘
┃ ┌═════════════════════════════════════════┐
└═>>█ ${white}Block Termux with SysO-Termux Login ${green}█
     └═════════════════════════════════════════┘

┌═══════════┐
█ ${white}SysO-Pass ${green}█
└═══════════┘
┃ ┌════════════════════════════════════════┐
└═>>█ ${white}Change SysO-Termux Login Data ${green}█
     └════════════════════════════════════════┘

┌═══════════┐
█ ${white}SysO-Sudo ${green}█
└═══════════┘
┃ ┌══════════════════════════════════════════┐
└═>>█ ${white}Change Normal User to Super User ${green}█
     └══════════════════════════════════════════┘

┌═══════════┐
█ ${white}SysO-Root ${green}█
└═══════════┘
┃ ┌═════════════════════════════════════════════┐
└═>>█ ${white}Forge and Change Normal User to Root ${green}█
     └═════════════════════════════════════════════┘

┌═══════════┐
█ ${white}SysO-BeEF ${green}█
└═══════════┘
┃ ┌════════════════════════════════════════════┐
└═>>█ ${white}Execute BeEF, Restarting the Database ${green}█
     └════════════════════════════════════════════┘

┌═══════════┐
█ ${white}SysO-GoPh ${green}█
└═══════════┘
┃ ┌══════════════════════════════════════┐
└═>>█ ${white}Automatic GoPhish Run ${green}█
     └══════════════════════════════════════┘

┌══════════┐
█ ${white}SysO-Msf ${green}█
└══════════┘
┃ ┌════════════════════════════════════════════┐
└═>>█ ${white} Run the Metasploit-Framework Console ${green}█
     └════════════════════════════════════════════┘

┌══════════┐
█ ${white}SysO-Rsf ${green}█
└══════════┘
┃ ┌═══════════════════════════════════════════┐
└═>>█ ${white}Automatic RouterSploit ${green}█
     └═══════════════════════════════════════════┘

┌═════════┐
█ ${white}SysO-IP ${green}█
└═════════┘
┃ ┌═════════════════════════════════════════┐
└═>>█ ${white}Print the Internet Service Provider's IP ${green}█
     └═════════════════════════════════════════┘

┌═══════════┐
█ ${white}SysO-Tool ${green}█
└═══════════┘
┃ ┌═══════════════════════════════════════┐
└═>>█ ${white}Does the Tool Installer ${green}█
     └═══════════════════════════════════════┘
"${white}

Translated with www.DeepL.com/Translator (free version)












█

"${blanco}
