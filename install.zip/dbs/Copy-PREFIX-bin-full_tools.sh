#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# VARIABLES
#
PWD=$(pwd)
source ${PWD}/Colors.sh
#
# CÓDIGO
#
if [ -x ${PREFIX}/bin/ ]
then
cd ${HOME}/SysO-Termux/full_tools
else
cd
clear
echo -e "${verde}
┌════════════════════════════════════┐
█ Instalando █
└════════════════════════════════════┘
"${blanco}



cd ${HOME}/SysO-Termux/full_tools
fi
