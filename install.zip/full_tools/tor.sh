#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# VARIABLES
#
PWD=$(pwd)
source ${PWD}/Colors.sh
#
# CÓDIGO
#
if [ -x ${PREFIX}/bin/tor ]
then
cd ${HOME}/SysO-Termux/full_tools
else
cd
clear
echo -e "${verde}
┌═══════════════════┐
█ ${blanco}Instalando tor... ${verde}█
└═══════════════════┘
"${blanco}
pkg install -y tor
cd ${HOME}/SysO-Termux/full_tools
fi
