#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# VARIABLES
#
PWD=$(pwd)
source ${PWD}/Colors.sh
#
# CÓDIGO
#
if [ -x ${HOME}/Gloom-Framework ]
then
cd ${HOME}/SysO-Termux/full_tools
else
cd
clear
echo -e "${verde}
┌═══════════════════════════════┐
█ ${blanco}Instalando Gloom-Framework... ${verde}█
└═══════════════════════════════┘
"${blanco}
pkg install -y python2
pip2 install --upgrade pip
pip2 install scapy
pip2 install requests
pip2 install pythonwhois
pip2 install bs4
pip2 install email
pip2 install termcolor
pip2 install urllib2
pip2 install mechanize
git clone https://github.com/StreetSec/Gloom-Framework
cd ${HOME}/SysO-Termux/full_tools
fi
