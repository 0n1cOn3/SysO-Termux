#!/bin/bash
#
# Created by: Informatic_in_Termux
#
# VARIABLES
#
PWD=$(pwd)
source ${PWD}/Colors.sh
#
# CÓDIGO
#
if [ -x ${HOME}/zipcrick ]
then
cd ${HOME}/SysO-Termux/full_tools
else
cd
clear
echo -e "${verde}
┌════════════════════════┐
█ ${blanco}Instalando zipcrick... ${verde}█
└════════════════════════┘
"${blanco}
pkg install -y python
git clone https://github.com/Fabr1x/zipcrick
cd ${HOME}/SysO-Termux/full_tools
fi
